public class User {
    String name;
    String surname;
    int date,month,year;

    public User(String name, String surname, int date, int month, int year) {
        this.name = name;
        this.surname = surname;
        this.date = date;
        this.month = month;
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getdate() {
        return date;
    }

    public void setdate(int date) {
        this.date = date;
    }
    
    public int getmonth() {
        return month;
    }

    public void setmonth(int month) {
        this.month = month;
    }
    
    public int getyear() {
        return year;
    }

    public void setyear(int year) {
        this.year = year;
    }
}
