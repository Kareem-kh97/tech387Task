import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.*; 

public class Main {

    public static void main(String args[]) {

        int numberOfUsers;

        Scanner sc = new Scanner(System.in);
        ArrayList<User> users = new ArrayList<>();
        ArrayList<User> userSearch = new ArrayList<>();
        String name;
        String surname;
        int date,month,year;
        int counter = 1;
        String search;

        System.out.println("Enter number of users you want to work with: ");
        numberOfUsers = sc.nextInt();

        for (int i = 0; i < numberOfUsers; i++) {


            System.out.println("Enter user " + counter + " name: ");
            name = sc.next();
            System.out.println("Enter user " + counter + " surname: ");
            surname = sc.next();
            System.out.println("Enter user " + counter + " birth date: ");
            date = sc.nextInt();
            System.out.println("Enter user " + counter + " birth month: ");
            month = sc.nextInt();
            System.out.println("Enter user " + counter + " birth year: ");
            year = sc.nextInt();
            counter += 1;
            System.out.println("***************************");
            users.add(new User(name, surname, date, month, year));

        }


        while (true) {

            System.out.println("1. Show all");
            System.out.println("2. Show data about oldest user ");
            System.out.println("3. Sort Users by Date of birth");
            System.out.println("4. Search by Name or Surname");
            System.out.println("5. Add new ");

            int choice;

            System.out.println("Enter your choice: ");
            choice = sc.nextInt();
            switch (choice) {

                case 1:
                	
                    for (User user : users) {
                    	 
                        System.out.println(user.getName() + " " + user.getSurname()+" "+user.getdate()+"-"+user.getmonth()+"-"+user.getyear());
                        System.out.println("***************************");
                    }
                    break;
                case 2:
                    System.out.println("The oldest user is : ");
                    System.out.println("Name : "+ users.get(0).getName());
                    System.out.println("Surname : "+ users.get(0).getSurname());
                    System.out.println("Date of Birth : "+ users.get(0).getdate()+"-"+users.get(0).getmonth()+"-"+users.get(0).getyear());
                    
                    break;
                case 3:
                    System.out.println("The sorted list is : ");
                    
                    int [][] dates = new int[3][users.size()];
                    
                    for ( int i=0;i<users.size();i++)
                    {
                        dates[0][i]=users.get(i).getyear();
                        dates[1][i]=users.get(i).getmonth();
                        dates[2][i]=users.get(i).getdate();
                    }
                    
                    for (int i = 0; i < dates.length; i++)   
                    {  
                        for (int j = i + 1; j < dates.length; j++)   
                        {  
                            int tmp = 0, tmp1=0, tmp2=0;  
                            if (dates[2][i] < dates[2][j])   
                            {  
                                        tmp = dates[0][i];  
                                        dates[0][i] = dates[0][j];  
                                        dates[0][j] = tmp;

                                        tmp1 = dates[1][i];  
                                        dates[1][i] = dates[1][j];  
                                        dates[1][j] = tmp1;

                                        tmp2 = dates[2][i];  
                                        dates[2][i] = dates[2][j];  
                                        dates[2][j] = tmp2;
                               
                                
                            }
                        }  
                    }    
                    
                    for (int i = 0; i < dates.length; i++)   
                    {  
                        for (int j = i + 1; j < dates.length; j++)   
                        {  
                            int tmp = 0, tmp1=0, tmp2=0;  
                            if (dates[1][i] < dates[1][j] )   
                            {  
                                        tmp = dates[0][i];  
                                        dates[0][i] = dates[0][j];  
                                        dates[0][j] = tmp;

                                        tmp1 = dates[1][i];  
                                        dates[1][i] = dates[1][j];  
                                        dates[1][j] = tmp1;

                                        tmp2 = dates[2][i];  
                                        dates[2][i] = dates[2][j];  
                                        dates[2][j] = tmp2;
                               
                                
                            }
                        }  
                    }    
                    

                    for (int i = 0; i < users.size(); i++)   
                    {  
                        for (int j = i + 1; j < users.size(); j++)   
                        {  
                            int tmp = 0, tmp1=0, tmp2=0;  
                            if (dates[0][i] < dates[0][j] )   
                            {  
                                        tmp = dates[0][i];  
                                        dates[0][i] = dates[0][j];  
                                        dates[0][j] = tmp;

                                        tmp1 = dates[1][i];  
                                        dates[1][i] = dates[1][j];  
                                        dates[1][j] = tmp1;

                                        tmp2 = dates[2][i];  
                                        dates[2][i] = dates[2][j];  
                                        dates[2][j] = tmp2;
                            }
                        }  
                    }    
                    
                    for ( int i=0;i<users.size();i++)
                    {
                        for (int j=0;j<users.size();j++)
                        {
                            if (users.get(j).getyear()==dates[0][i] && users.get(j).getmonth()==dates[1][i] && users.get(j).getdate()==dates[2][i])
                            {
                                System.out.println(users.get(j).getName() + " " + users.get(j).getSurname()+" "+users.get(j).getdate()+"-"+users.get(j).getmonth()+"-"+users.get(j).getyear());
                            }
                        }
//                        System.out.println(dates[2][i]+"-"+dates[1][i]+"-"+dates[0][i]);
                    }
                    
                    break;
                case 4:
                    System.out.println("Enter user name or user surname");
                    search = sc.next();

          for (User user:users){

              if (user.getName().equals(search) || user.getSurname().equals(search)){
                  userSearch.add(new User(user.name,user.getSurname(),user.getdate(),user.getmonth(),user.getyear()));
                  System.out.println(user.getName()+" "+user.getSurname()+" "+user.getdate()+"-"+user.getmonth()+"-"+user.getyear());
                  break;
              }

          }

if (userSearch.isEmpty()){
    System.out.println("No user ");
}
                    break;

                case 5:

                    System.out.println("Enter user name: ");
                    name = sc.next();
                    System.out.println("Enter user surname: ");
                    surname = sc.next();
                    System.out.println("Enter user birth date: ");
                    date = sc.nextInt();
                    System.out.println("Enter user birth month: ");
                    month = sc.nextInt();
                    System.out.println("Enter user birth year: ");
                    year = sc.nextInt();

                    users.add(new User(name, surname, date, month, year));
                    for (User user : users) {
                        System.out.println(user.getName() + " " + user.getSurname()+" "+user.getdate()+"-"+user.getmonth()+"-"+user.getyear());
                    }
                    break;

            }


        }
    }