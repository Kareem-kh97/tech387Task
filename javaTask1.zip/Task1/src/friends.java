import java.util.Scanner;
public class friends {

	public friends() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] arg) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please type how many users you wnna to work with: ");
		
		int users = sc.nextInt();
		String name;
		String surname;
		int counter = 0;
		while (counter < users) {
		name = sc.nextLine(); 
		surname = sc.nextLine();
		counter ++;

		}
			System.out.println();							
	}

}
